<?php
include 'config.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = $_POST['email'];
    $errors = [];

    if (empty($_POST['first_name'])) $errors[] = "First Name is required.";
    if (empty($_POST['last_name'])) $errors[] = "Last Name is required.";
    if (empty($_POST['phone_number']) || !preg_match('/^[0-9]{10,15}$/', $_POST['phone_number'])) $errors[] = "Phone number must be 10-15 digits.";
    if (empty($_POST['address'])) $errors[] = "Address is required.";

    if (empty($errors)) {
        $stmt = $conn->prepare("UPDATE users SET first_name=?, last_name=?, phone_number=?, address=? WHERE email=?");
        $stmt->bind_param("sssss", $_POST['first_name'], $_POST['last_name'], $_POST['phone_number'], $_POST['address'], $email);

        if ($stmt->execute()) {
            header("Location: index.php");
            exit;
        } else {
            echo "Error: " . $stmt->error;
        }
    } else {
        foreach ($errors as $e) {
            echo "<p style='color:red;'>$e</p>";
        }
        echo "<a href='edit.php?email=$email'>Go Back</a>";
    }
}
?>
