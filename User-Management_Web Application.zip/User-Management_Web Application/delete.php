<?php
include 'config.php';

if (isset($_GET['email'])) {
    $email = $_GET['email'];
    $conn->query("DELETE FROM users WHERE email = '$email'");
}

header("Location: index.php");
exit;
?>
