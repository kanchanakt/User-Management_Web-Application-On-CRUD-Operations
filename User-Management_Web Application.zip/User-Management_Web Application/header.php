<!DOCTYPE html>
<html>
<head>
    <title>WEB App</title>
    <link rel="stylesheet" href="style.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@600&display=swap" rel="stylesheet">
    <style>
        body {
            margin: 0;
            padding: 0;
            font-family: Arial, sans-serif;
        }
        .navbar {
            background-color: #2c3e50;
            padding: 15px 0;
            text-align: center;
        }
        .navbar h2 {
            color: #ecf0f1;
            margin: 0 0 15px 0;
            font-weight: bold;
            text-transform: uppercase;
            letter-spacing: 2px;
            font-family: 'Poppins', sans-serif;
            font-size: 28px;
        }
        .navbar a {
            color: #ecf0f1;
            text-decoration: none;
            margin: 0 10px;
            font-weight: bold;
            padding: 8px 15px;
            border: 2px solid #ecf0f1;
            border-radius: 5px;
            display: inline-block;
            transition: all 0.3s ease;
        }
        .navbar a:hover {
            background: #ecf0f1;
            color: #2c3e50;
        }
    </style>
</head>
<body>
    <div class="navbar">
        <h2>User Management System</h2>
        <div>
            <a href="home.php">Home Page</a> 
            <a href="index.php">User List</a> 
            <a href="add.php">Add New User</a>
        </div>
    </div>
