<style>
    footer {
        background-color: #2c3e50;
        padding: 20px 0;
        text-align: center;
        color: #ecf0f1;
        font-weight: bold;
        font-family: Arial, sans-serif;
        border-top: 0px solid #1a252f;
        position: relative;
        z-index: 10;
    }
</style>
<footer>
    <p></p>
</footer>
