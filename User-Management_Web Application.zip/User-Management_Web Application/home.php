<?php include 'header.php'; ?>

<style>
    body {
        font-family: Arial, sans-serif;
        background-color: #f0f4f8;
        margin: 0;
        padding: 0;
    }
    .container {
        max-width: 800px;
        margin: 50px auto;
        background: #ffffff;
        padding: 30px;
        border-radius: 10px;
        box-shadow: 0 4px 8px rgba(0,0,0,0.1);
    }
    h2 {
        color: #2c3e50;
        margin-bottom: 15px;
        text-align: center;
    }
    p {
        font-size: 16px;
        color: #555;
        margin-bottom: 20px;
        text-align: center;
    }
    ul {
        list-style: none;
        padding: 0;
    }
    ul li {
        background: #dfe9f3;
        margin: 10px 0;
        padding: 12px;
        border-left: 5px solid #3498db;
        transition: 0.3s;
        border-radius: 5px;
        font-weight: bold;
        color: #2c3e50;
        box-shadow: 0 2px 5px rgba(0, 0, 0, 0.05);
    }
    ul li:hover {
        background: #c9dced;
    }
    .nav {
        margin-bottom: 30px;
    }
</style>
<center>

<div class="container">
    <h2>Welcome to the User Management System</h2>

    <p>This simple application allows you to:</p>
    <ul>
        <li>Add new users</li>
        <li>View the list of users</li>
        <li>Edit user information</li>
        <li>Delete users from the system</li>
    </ul>
    <p>Use the navigation links above to get started!</p>
</div>
</center>

<?php include 'footer.php'; ?>
