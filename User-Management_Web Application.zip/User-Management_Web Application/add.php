<?php
include 'config.php';
include 'header.php';
$errors = [];

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (empty($_POST['first_name'])) $errors[] = "First Name is required.";
    if (empty($_POST['last_name'])) $errors[] = "Last Name is required.";
    if (empty($_POST['phone_number']) || !preg_match('/^[0-9]{10,15}$/', $_POST['phone_number'])) $errors[] = "Phone number must be 10-15 digits.";
    if (empty($_POST['email']) || !filter_var($_POST['email'], FILTER_VALIDATE_EMAIL)) $errors[] = "Valid email required.";
    if (empty($_POST['address'])) $errors[] = "Address is required.";

    if (empty($errors)) {
        $stmt = $conn->prepare("INSERT INTO users (first_name, last_name, phone_number, email, address) VALUES (?, ?, ?, ?, ?)");
        $stmt->bind_param("sssss", $_POST['first_name'], $_POST['last_name'], $_POST['phone_number'], $_POST['email'], $_POST['address']);
        if ($stmt->execute()) {
            header("Location: index.php");
            exit;
        } else {
            $errors[] = "Error: " . $stmt->error;
        }
    }
}
?>

<style>
    body {
        background-color: #ecf0f3;
        font-family: Arial, sans-serif;
        margin: 0;
        padding: 0;
    }
    .form-container {
        max-width: 500px;
        margin: 50px auto;
        background: #ffffff;
        padding: 30px;
        border-radius: 10px;
        box-shadow: 0 4px 8px rgba(0,0,0,0.1);
    }
    .form-container h3 {
        text-align: center;
        color: #2c3e50;
        margin-bottom: 20px;
        font-family: 'Poppins', sans-serif;
    }
    label {
        display: block;
        font-weight: bold;
        margin-bottom: 5px;
        color: #34495e;
    }
    input[type="text"], input[type="email"] {
        width: 100%;
        padding: 10px;
        margin-bottom: 15px;
        border-radius: 5px;
        border: 1px solid #ccc;
        transition: border 0.3s;
    }
    input[type="text"]:focus, input[type="email"]:focus {
        border: 1px solid #3498db;
        outline: none;
    }
    input[type="submit"] {
        background: #3498db;
        color: #fff;
        padding: 10px 25px;
        border: none;
        border-radius: 5px;
        font-weight: bold;
        cursor: pointer;
        width: 100%;
        transition: 0.3s;
    }
    input[type="submit"]:hover {
        background: #2980b9;
    }
    .error-msg {
        color: red;
        font-size: 14px;
        margin-bottom: 10px;
    }
</style>


<div class="form-container">
    <h3>Add New User</h3>
    <?php foreach ($errors as $e) echo "<div class='error-msg'>$e</div>"; ?>
    <form method="POST">
        <label>First Name:</label>
        <input type="text" name="first_name">
        <label>Last Name:</label>
        <input type="text" name="last_name">
        <label>Phone Number:</label>
        <input type="text" name="phone_number">
        <label>Email:</label>
        <input type="email" name="email">
        <label>Address:</label>
        <input type="text" name="address">
        <input type="submit" value="Add User">
    </form>
</div>

<?php include 'footer.php'; ?>
