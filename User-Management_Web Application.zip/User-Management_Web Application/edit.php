<?php
include 'config.php';
include 'header.php';

$email = $_GET['email'];
$result = $conn->query("SELECT * FROM users WHERE email='$email'");
$row = $result->fetch_assoc();
$errors = [];

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (empty($_POST['first_name'])) $errors[] = "First Name is required.";
    if (empty($_POST['last_name'])) $errors[] = "Last Name is required.";
    if (empty($_POST['phone_number']) || !preg_match('/^[0-9]{10,15}$/', $_POST['phone_number'])) $errors[] = "Phone number must be 10-15 digits.";
    if (empty($_POST['email']) || !filter_var($_POST['email'], FILTER_VALIDATE_EMAIL)) $errors[] = "Valid email required.";
    if (empty($_POST['address'])) $errors[] = "Address is required.";

    if (empty($errors)) {
        $stmt = $conn->prepare("UPDATE users SET first_name=?, last_name=?, phone_number=?, email=?, address=?, updated_at=NOW() WHERE email=?");
        $stmt->bind_param("ssssss", $_POST['first_name'], $_POST['last_name'], $_POST['phone_number'], $_POST['email'], $_POST['address'], $email);
        if ($stmt->execute()) {
            header("Location: index.php");
            exit;
        } else {
            $errors[] = "Error: " . $stmt->error;
        }
    }
}
?>

<style>
    body {
        font-family: Arial, sans-serif;
        background-color: #f0f4f8;
        margin: 0;
        padding: 0;
    }
    .container {
        max-width: 600px;
        margin: 50px auto;
        background: #ffffff;
        padding: 30px;
        border-radius: 10px;
        box-shadow: 0 4px 8px rgba(0,0,0,0.1);
    }
    h3 {
        text-align: center;
        color: #2c3e50;
        margin-bottom: 20px;
    }
    label {
        display: block;
        margin-bottom: 8px;
        color: #34495e;
        font-weight: bold;
    }
    input[type="text"], input[type="email"] {
        width: 100%;
        padding: 10px;
        margin-bottom: 15px;
        border: 1px solid #ccc;
        border-radius: 5px;
    }
    input[type="submit"] {
        background: #2c3e50;
        color: #fff;
        border: none;
        padding: 12px 20px;
        width: 100%;
        border-radius: 5px;
        font-weight: bold;
        cursor: pointer;
        transition: 0.3s;
    }
    input[type="submit"]:hover {
        background: #34495e;
    }
    .error {
        color: red;
        margin-bottom: 10px;
    }
</style>

<div class="container">
    <h3>Edit User</h3>
    <?php foreach ($errors as $e) echo "<p class='error'>$e</p>"; ?>
    <form method="POST">
        <label>First Name:</label>
        <input type="text" name="first_name" value="<?php echo $row['first_name']; ?>">
        <label>Last Name:</label>
        <input type="text" name="last_name" value="<?php echo $row['last_name']; ?>">
        <label>Phone Number:</label>
        <input type="text" name="phone_number" value="<?php echo $row['phone_number']; ?>">
        <label>Email:</label>
        <input type="email" name="email" value="<?php echo $row['email']; ?>">
        <label>Address:</label>
        <input type="text" name="address" value="<?php echo $row['address']; ?>">
        <input type="submit" value="Update User">
    </form>
</div>

<?php include 'footer.php'; ?>
