<?php include 'config.php'; include 'header.php'; ?>

<style>
    body {
        font-family: Arial, sans-serif;
        background-color: #f0f4f8;
        margin: 0;
        padding: 0;
    }
    .container {
        max-width: 1000px;
        margin: 50px auto;
        background: #ffffff;
        padding: 30px;
        border-radius: 10px;
        box-shadow: 0 4px 8px rgba(0,0,0,0.1);
    }
    h3 {
        color: #2c3e50;
        text-align: center;
        margin-bottom: 20px;
    }
    table {
        width: 100%;
        border-collapse: collapse;
    }
    th {
        background-color: #2c3e50;
        color: #fff;
        padding: 12px;
        text-transform: uppercase;
    }
    td {
        padding: 10px;
        text-align: center;
    }
    tr:nth-child(even) {
        background-color: #f9f9f9;
    }
    tr:hover {
        background-color: #f1f1f1;
    }
    a {
        text-decoration: none;
        padding: 5px 10px;
        border-radius: 4px;
        color: #fff;
        margin: 0 3px;
        display: inline-block;
        font-size: 14px;
    }
    .edit-btn {
        background: #27ae60;
    }
    .delete-btn {
        background: #e74c3c;
    }
</style>

<div class="container">
    <h3>User List</h3>
    <table border="1">
        <tr>
            <th>First Name</th>
            <th>Last Name</th>
            <th>Phone Number</th>
            <th>Email</th>
            <th>Address</th>
            <th>Created At</th>
            <th>Updated At</th>
            <th>Actions</th>
        </tr>
        <?php
        $result = $conn->query("SELECT * FROM users");
        while ($row = $result->fetch_assoc()) {
            echo "<tr>
                <td>{$row['first_name']}</td>
                <td>{$row['last_name']}</td>
                <td>{$row['phone_number']}</td>
                <td>{$row['email']}</td>
                <td>{$row['address']}</td>
                <td>{$row['created_at']}</td>
                <td>{$row['updated_at']}</td>
                <td>
                    <a class='edit-btn' href='edit.php?email={$row['email']}'>Edit</a> <br> <br>
                    <a class='delete-btn' href='delete.php?email={$row['email']}' onclick=\"return confirm('Are you sure?')\">Delete</a>
                </td>
            </tr>";
        }
        ?>
    </table>
</div>

<?php include 'footer.php'; ?>
